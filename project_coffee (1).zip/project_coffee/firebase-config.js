const FB_VER = "https://www.gstatic.com/firebasejs/12.15.0";

import { initializeApp } from "https://www.gstatic.com/firebasejs/12.15.0/firebase-app.js";
import { getFirestore }  from "https://www.gstatic.com/firebasejs/12.15.0/firebase-firestore.js";

const firebaseConfig = {
    apiKey:            "AIzaSyCcInzW8gluIdscX0Z-hfIL31uRf38ZjD4",
    authDomain:        "project-coffee-3b9b1.firebaseapp.com",
    projectId:         "project-coffee-3b9b1",
    storageBucket:     "project-coffee-3b9b1.firebasestorage.app",
    messagingSenderId: "413915459644",
    appId:             "1:413915459644:web:b5b2a45f936c6e6ad51339",
    measurementId:     "G-BNWK9HW0HN"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);