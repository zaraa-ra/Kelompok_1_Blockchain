export const CONTRACT_ADDRESS = "0x3dD9A0a68fe8694D4510644eD92b714009214Cd2"; 

export const ABI = [
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "_batchID",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_location",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_variety",
				"type": "string"
			},
			{
				"internalType": "uint256",
				"name": "_harvestDate",
				"type": "uint256"
			}
		],
		"name": "addBatch",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "_actor",
				"type": "address"
			},
			{
				"internalType": "enum CoffeeSupplyChain.Role",
				"name": "_role",
				"type": "uint8"
			}
		],
		"name": "authorizeActor",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"stateMutability": "nonpayable",
		"type": "constructor"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "string",
				"name": "batchID",
				"type": "string"
			},
			{
				"indexed": true,
				"internalType": "address",
				"name": "farmer",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "location",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "variety",
				"type": "string"
			}
		],
		"name": "BatchAdded",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": true,
				"internalType": "address",
				"name": "actor",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "enum CoffeeSupplyChain.Role",
				"name": "role",
				"type": "uint8"
			}
		],
		"name": "RoleAssigned",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "string",
				"name": "batchID",
				"type": "string"
			},
			{
				"indexed": true,
				"internalType": "address",
				"name": "roaster",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "roastProfile",
				"type": "string"
			}
		],
		"name": "StatusUpdatedToRoasted",
		"type": "event"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "_batchID",
				"type": "string"
			},
			{
				"internalType": "uint256",
				"name": "_roastDate",
				"type": "uint256"
			},
			{
				"internalType": "string",
				"name": "_roastProfile",
				"type": "string"
			}
		],
		"name": "updateToRoaster",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"name": "actorRoles",
		"outputs": [
			{
				"internalType": "enum CoffeeSupplyChain.Role",
				"name": "",
				"type": "uint8"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "admin",
		"outputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "_batchID",
				"type": "string"
			}
		],
		"name": "getBatchDetails",
		"outputs": [
			{
				"internalType": "string",
				"name": "batchID",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "location",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "variety",
				"type": "string"
			},
			{
				"internalType": "uint256",
				"name": "harvestDate",
				"type": "uint256"
			},
			{
				"internalType": "uint256",
				"name": "roastDate",
				"type": "uint256"
			},
			{
				"internalType": "string",
				"name": "roastProfile",
				"type": "string"
			},
			{
				"internalType": "address",
				"name": "farmer",
				"type": "address"
			},
			{
				"internalType": "address",
				"name": "roaster",
				"type": "address"
			},
			{
				"internalType": "address",
				"name": "currentOwner",
				"type": "address"
			},
			{
				"internalType": "enum CoffeeSupplyChain.Status",
				"name": "status",
				"type": "uint8"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "_batchID",
				"type": "string"
			}
		],
		"name": "getBatchStatus",
		"outputs": [
			{
				"internalType": "enum CoffeeSupplyChain.Status",
				"name": "",
				"type": "uint8"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "_batchID",
				"type": "string"
			}
		],
		"name": "verifyOrigin",
		"outputs": [
			{
				"internalType": "bool",
				"name": "",
				"type": "bool"
			}
		],
		"stateMutability": "view",
		"type": "function"
	}
];