import { CONTRACT_ADDRESS, ABI } from './contract.js';
import { db } from './firebase-config.js';
import {
    collection, addDoc, getDocs, deleteDoc, updateDoc, doc, query, where, serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.15.0/firebase-firestore.js";

// enum Role di Solidity: None=0, Farmer=1, Roaster=2
const ROLE = { NONE: 0, FARMER: 1, ROASTER: 2 };

// ===================== HELPER TAMPILAN =====================
function showSection(id) {
    ['heroSection','registrationSection','adminPortal','petaniPortal','roasterPortal']
        .forEach(s => {
            const el = document.getElementById(s);
            if (el) el.style.display = 'none';
        });
    document.getElementById(id).style.display = 'block';
    document.querySelector('footer').style.display = 'none';
}

// ===================== CONNECT WALLET =====================
let userSigner = null;
let userAddress = null;

document.getElementById('connectWalletBtn').addEventListener('click', async () => {
    const btn = document.getElementById('connectWalletBtn');
    try {
        if (!window.ethereum) { alert("Harap install MetaMask!"); return; }

        btn.textContent = "Menghubungkan...";
        btn.disabled = true;

        const provider = new ethers.BrowserProvider(window.ethereum);

        // Paksa popup pemilih akun setiap kali klik
        try {
            await provider.send("wallet_requestPermissions", [{ eth_accounts: {} }]);
        } catch (e) {
            if (e.code === 4001) { btn.textContent = "Connect Wallet"; btn.disabled = false; return; }
        }

        await provider.send("eth_requestAccounts", []);
        userSigner  = await provider.getSigner();
        userAddress = await userSigner.getAddress();

        const readContract = new ethers.Contract(CONTRACT_ADDRESS, ABI, provider);
        const [adminAddr, roleRaw] = await Promise.all([
            readContract.admin(),
            readContract.actorRoles(userAddress)
        ]);
        const role = Number(roleRaw);
        const isAdmin = adminAddr.toLowerCase() === userAddress.toLowerCase();

        if (isAdmin) {
            showSection('adminPortal');
            document.getElementById('adminWalletBtn').textContent = userAddress.substring(0,6) + '...';
            btn.textContent = "Admin Portal";
            renderPendingTable();
        } else if (role === ROLE.FARMER) {
            showSection('petaniPortal');
            document.getElementById('petaniWalletBtn').textContent = userAddress.substring(0,6) + '...';
            document.getElementById('harvestDateDisplay').textContent = new Date().toLocaleDateString('id-ID');
            btn.textContent = "Portal Petani";
        } else if (role === ROLE.ROASTER) {
            showSection('roasterPortal');
            document.getElementById('roasterWalletBtn').textContent = userAddress.substring(0,6) + '...';
            document.getElementById('roastDateDisplay').textContent = new Date().toLocaleDateString('id-ID');
            btn.textContent = "Portal Roaster";
        } else {
            btn.textContent = `Konsumen (${userAddress.substring(0,6)}...)`;
            alert("Anda terhubung sebagai Konsumen. Wallet ini belum diotorisasi Admin.");
        }

    } catch (err) {
        console.error(err);
        btn.textContent = "Connect Wallet";
        alert("Gagal koneksi: " + (err.shortMessage || err.message));
    } finally {
        btn.disabled = false;
    }
});

// Disconnect (reload halaman)
['adminWalletBtn','petaniWalletBtn','roasterWalletBtn'].forEach(id => {
    document.getElementById(id)?.addEventListener('click', () => window.location.reload());
});

// ===================== FORM PENDAFTARAN MITRA (UMUM) =====================
const partnerForm = document.getElementById('partnerForm');
if (partnerForm) {
    partnerForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const submitBtn = partnerForm.querySelector('button[type="submit"]');
        submitBtn.disabled = true;
        submitBtn.textContent = "Mengirim...";

        try {
            const walletInput = document.getElementById('partnerWallet').value.trim().toLowerCase();

            // Cek apakah wallet sudah terdaftar di Firestore (pending atau authorized)
            const dupCheck = await getDocs(query(collection(db, "pendaftaran"),
                where("wallet", "==", walletInput)));
            if (!dupCheck.empty) {
                alert("Alamat wallet ini sudah pernah didaftarkan sebelumnya.");
                submitBtn.disabled = false;
                submitBtn.textContent = "▻ Kirim Pengajuan Mitra";
                return;
            }

            // Cek apakah wallet sudah punya role di blockchain
            const providerCheck = window.ethereum
                ? new ethers.BrowserProvider(window.ethereum)
                : ethers.getDefaultProvider("sepolia");
            const contractCheck = new ethers.Contract(CONTRACT_ADDRESS, ABI, providerCheck);
            const roleOnChain   = Number(await contractCheck.actorRoles(walletInput));
            if (roleOnChain !== 0) {
                alert("Alamat wallet ini sudah terotorisasi di blockchain.");
                submitBtn.disabled = false;
                submitBtn.textContent = "▻ Kirim Pengajuan Mitra";
                return;
            }

            await addDoc(collection(db, "pendaftaran"), {
                nama:      document.getElementById('partnerNama').value.trim(),
                nik:       document.getElementById('partnerNIK').value.trim(),
                email:     document.getElementById('partnerEmail').value.trim(),
                usaha:     document.getElementById('partnerUsaha').value.trim(),
                lokasi:    document.getElementById('partnerLokasi').value.trim(),
                role:      document.getElementById('partnerRole').value,       // "1" atau "2"
                roleLabel: document.getElementById('partnerRole').options[document.getElementById('partnerRole').selectedIndex].text,
                wallet:    document.getElementById('partnerWallet').value.trim().toLowerCase(),
                status:    "pending",
                createdAt: serverTimestamp()
            });

            const msg = document.getElementById('partnerSuccessMsg');
            msg.style.display = 'block';
            partnerForm.reset();
            setTimeout(() => { msg.style.display = 'none'; }, 6000);
        } catch (err) {
            console.error(err);
            alert("Gagal mengirim: " + err.message);
        } finally {
            submitBtn.disabled = false;
            submitBtn.textContent = "▻ Kirim Pengajuan Mitra";
        }
    });
}

// ===================== ADMIN: RENDER TABEL PENDING =====================
async function renderPendingTable() {
    const tbody   = document.getElementById('tableBody');
    const table   = document.getElementById('adminTable');
    const empty   = document.getElementById('pendingEmptyState');

    document.getElementById('tableHeader').innerHTML = `
        <th>Nama</th><th>NIK</th><th>Email</th>
        <th>Usaha & Lokasi</th><th>Peran</th><th>Wallet</th><th>Aksi</th>`;
    tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;padding:20px;color:#aaa;">Memuat data...</td></tr>';
    table.style.display = 'table';
    empty.style.display = 'none';
    document.getElementById('authorizedEmptyState').style.display = 'none';

    try {
        const q    = query(collection(db, "pendaftaran"), where("status", "==", "pending"));
        const snap = await getDocs(q);

        if (snap.empty) {
            table.style.display = 'none';
            empty.style.display = 'block';
            return;
        }

        tbody.innerHTML = '';
        snap.forEach(docSnap => {
            const d  = docSnap.data();
            const tr = document.createElement('tr');
            const roleBadge = d.role === '1'
                ? `<span class="badge-role-petani">Petani Kopi</span>`
                : `<span class="badge-role-roaster">Roaster Kopi</span>`;

            tr.innerHTML = `
                <td><b>${d.nama}</b></td>
                <td>${d.nik}</td>
                <td>${d.email}</td>
                <td><b>${d.usaha}</b><br><small style="color:#888;">${d.lokasi}</small></td>
                <td>${roleBadge}</td>
                <td><code style="font-size:11px;">${d.wallet}</code></td>
                <td>
                    <button class="btn-acc" data-id="${docSnap.id}" data-wallet="${d.wallet}" data-role="${d.role}" data-nama="${d.nama}">
                        ✔ ACC
                    </button><br>
                    <button class="btn-rej" data-id="${docSnap.id}" data-nama="${d.nama}">
                        ✗ Tolak
                    </button>
                </td>`;
            tbody.appendChild(tr);
        });

        // Delegasi event untuk tombol ACC & Tolak
        tbody.addEventListener('click', handleTableAction);

    } catch (err) {
        console.error(err);
        tbody.innerHTML = `<tr><td colspan="7" style="color:red;">Gagal memuat data: ${err.message}</td></tr>`;
    }
}

// ===================== ADMIN: HANDLER ACC & TOLAK =====================
async function handleTableAction(e) {
    const accBtn = e.target.closest('.btn-acc');
    const rejBtn = e.target.closest('.btn-rej');

    if (accBtn) {
        const { id, wallet, role, nama } = accBtn.dataset;
        openAuthModal(id, wallet, role, nama);
    }

    if (rejBtn) {
        const { id, nama } = rejBtn.dataset;
        const ok = confirm(`Yakin ingin menolak pengajuan dari "${nama}"? Data akan dihapus permanen.`);
        if (!ok) return;
        try {
            await deleteDoc(doc(db, "pendaftaran", id));
            renderPendingTable();
        } catch (err) {
            alert("Gagal menolak: " + err.message);
        }
    }
}

// ===================== MODAL OTORISASI =====================
let currentAuthDocId = null;

function openAuthModal(docId, wallet, role, nama) {
    currentAuthDocId = docId;
    document.getElementById('authModalName').textContent   = nama;
    document.getElementById('authModalWallet').value       = wallet;
    document.getElementById('authModalRole').value         = role;
    document.getElementById('authModal').style.display     = 'flex';
}

document.getElementById('authModalCancelBtn').addEventListener('click', () => {
    document.getElementById('authModal').style.display = 'none';
    currentAuthDocId = null;
});

document.getElementById('authModalConfirmBtn').addEventListener('click', async () => {
    const btn    = document.getElementById('authModalConfirmBtn');
    const wallet = document.getElementById('authModalWallet').value;
    const role   = parseInt(document.getElementById('authModalRole').value);

    btn.disabled     = true;
    btn.textContent  = "Menunggu MetaMask...";

    try {
        const contract = new ethers.Contract(CONTRACT_ADDRESS, ABI, userSigner);
        const tx = await contract.authorizeActor(wallet, role);
        btn.textContent = "Memproses transaksi...";
        await tx.wait();

        // Update status jadi authorized di Firestore (tetap tersimpan untuk Buku Induk)
        await updateDoc(doc(db, "pendaftaran", currentAuthDocId), { status: "authorized" });

        document.getElementById('authModal').style.display = 'none';
        alert(`Berhasil! ${wallet} kini terotorisasi sebagai ${role === 1 ? 'Petani' : 'Roaster'}.`);
        renderPendingTable();
    } catch (err) {
        console.error(err);
        alert("Gagal: " + (err.shortMessage || err.message));
    } finally {
        btn.disabled    = false;
        btn.textContent = "Setujui & Bayar Gas";
        currentAuthDocId = null;
    }
});

// ===================== PELACAKAN (KONSUMEN & QR) =====================
document.getElementById('searchDataBtn')?.addEventListener('click', async () => {
    const batchID = document.getElementById('batchIdInput').value.trim();
    if (!batchID) { alert("Masukkan ID Kopi!"); return; }
    await fetchAndShowBatch(batchID);
});

document.getElementById('startScanBtn')?.addEventListener('click', () => {
    const html5QrCode = new Html5Qrcode("reader");
    document.getElementById('qr-icon').style.display = 'none';
    document.getElementById('qr-text').style.display = 'none';

    html5QrCode.start(
        { facingMode: "environment" },
        { fps: 10, qrbox: { width: 250, height: 250 } },
        async (text) => {
            await html5QrCode.stop();
            const id = text.includes("?id=") ? text.split("?id=")[1] : text;
            document.getElementById('batchIdInput').value = id;
            await fetchAndShowBatch(id);
        },
        () => {}
    ).catch(() => alert("Gagal membuka kamera!"));
});

async function fetchAndShowBatch(batchID) {
    try {
        const provider = window.ethereum
            ? new ethers.BrowserProvider(window.ethereum)
            : ethers.getDefaultProvider("sepolia");
        const contract = new ethers.Contract(CONTRACT_ADDRESS, ABI, provider);
        const d = await contract.getBatchDetails(batchID);

        const statusNum = Number(d[9]);
        document.getElementById('trackBatchTitle').textContent  = `Detail Batch: ${batchID}`;
        document.getElementById('trackFarmer').textContent      = d[6];
        document.getElementById('trackLocation').textContent    = d[1];
        document.getElementById('trackVariety').textContent     = d[2];
        document.getElementById('trackHarvestDate').textContent = d[3] > 0
            ? new Date(Number(d[3]) * 1000).toLocaleDateString('id-ID') : '-';

        const badge = document.getElementById('trackStatusBadge');
        if (statusNum === 0) { badge.textContent = 'Mentah (Harvested)'; badge.className = 'status-badge'; }
        else                 { badge.textContent = 'Siap Seduh (Roasted)'; badge.className = 'status-badge roasted'; }

        const stage2 = document.getElementById('trackStage2');
        if (statusNum >= 1) {
            stage2.style.opacity = '1';
            document.getElementById('trackRoaster').textContent     = d[7];
            document.getElementById('trackRoastProfile').textContent = d[5] || '-';
            document.getElementById('trackRoastDate').textContent   = d[4] > 0
                ? new Date(Number(d[4]) * 1000).toLocaleDateString('id-ID') : '-';
        } else {
            stage2.style.opacity = '0.4';
            document.getElementById('trackRoaster').textContent     = 'Belum diproses';
            document.getElementById('trackRoastProfile').textContent = '-';
            document.getElementById('trackRoastDate').textContent   = '-';
        }

        document.getElementById('trackModal').style.display = 'flex';
    } catch (err) {
        console.error(err);
        alert("Data Kopi tidak ditemukan atau terjadi kesalahan!");
    }
}

document.getElementById('closeTrackModalBtn')?.addEventListener('click', () => {
    document.getElementById('trackModal').style.display = 'none';
});

// ===================== PORTAL PETANI =====================
const farmForm = document.getElementById('farmForm');
if (farmForm) {
    farmForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const id    = document.getElementById('batchID').value.trim();
        const loc   = document.getElementById('location').value.trim();
        const varo  = document.getElementById('variety').value.trim();
        const btn   = document.getElementById('submitBatchBtn');

        if (!userSigner) { alert("Wallet belum terhubung!"); return; }

        try {
            btn.disabled    = true;
            btn.textContent = "Sedang Memproses... (Jangan tutup halaman)";
            const contract  = new ethers.Contract(CONTRACT_ADDRESS, ABI, userSigner);
            const tx = await contract.addBatch(id, loc, varo, Math.floor(Date.now() / 1000));
            await tx.wait();

            document.getElementById('qrBatchInfo').textContent = `ID Kopi: ${id}`;
            document.getElementById('qrCodeTarget').innerHTML  = '';
            new QRCode(document.getElementById('qrCodeTarget'), {
                text: `https://www.coffeeteam.com/track?id=${id}`,
                width: 160, height: 160
            });
            document.getElementById('qrModal').style.display = 'flex';
            farmForm.reset();
        } catch (err) {
            console.error(err);
            alert("Gagal: " + (err.shortMessage || err.message));
        } finally {
            btn.disabled    = false;
            btn.textContent = "Daftarkan ke Blockchain";
        }
    });
}

document.getElementById('qrCloseBtn')?.addEventListener('click', () => {
    document.getElementById('qrModal').style.display = 'none';
});

// ===================== PORTAL ROASTER: SCAN =====================
document.getElementById('startRoasterScanBtn')?.addEventListener('click', () => {
    const html5QrCode = new Html5Qrcode("roasterReader");
    html5QrCode.start(
        { facingMode: "environment" },
        { fps: 10, qrbox: { width: 250, height: 250 } },
        (text) => {
            html5QrCode.stop().then(() => {
                const id = text.includes("?id=") ? text.split("?id=")[1] : text;
                document.getElementById('roastBatchID').value = id;
            });
        },
        () => {}
    ).catch(() => alert("Gagal membuka kamera!"));
});

// ===================== PORTAL ROASTER: FORM =====================
const roasterForm = document.getElementById('roasterForm');
if (roasterForm) {
    roasterForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const id      = document.getElementById('roastBatchID').value.trim();
        const profile = document.getElementById('roastProfile').value;
        const btn     = document.getElementById('updateRoastBtn');

        if (!userSigner) { alert("Wallet belum terhubung!"); return; }
        if (!id)         { alert("Scan QR Code karung kopi terlebih dahulu!"); return; }

        try {
            btn.disabled    = true;
            btn.textContent = "Sedang Menyimpan... (Jangan tutup halaman)";
            const contract  = new ethers.Contract(CONTRACT_ADDRESS, ABI, userSigner);
            const tx = await contract.updateToRoaster(id, Math.floor(Date.now() / 1000), profile);
            await tx.wait();
            alert(`☑ Sukses! Kopi Batch ${id} telah resmi diperbarui menjadi status Roasted.`);
            roasterForm.reset();
        } catch (err) {
            console.error(err);
            alert("Gagal: " + (err.shortMessage || err.message));
        } finally {
            btn.disabled    = false;
            btn.textContent = "Perbarui Status ke Blockchain";
        }
    });
}

// ===================== TAB SWITCHING ADMIN =====================
document.getElementById('tabPending')?.addEventListener('click', () => {
    document.getElementById('tabPending').classList.add('active');
    document.getElementById('tabAuthorized').classList.remove('active');
    renderPendingTable();
});

document.getElementById('tabAuthorized')?.addEventListener('click', () => {
    document.getElementById('tabAuthorized').classList.add('active');
    document.getElementById('tabPending').classList.remove('active');
    renderAuthorizedTable();
});

// ===================== BUKU INDUK MITRA =====================
async function renderAuthorizedTable() {
    const tbody     = document.getElementById('tableBody');
    const table     = document.getElementById('adminTable');
    const emptyPend = document.getElementById('pendingEmptyState');
    const emptyAuth = document.getElementById('authorizedEmptyState');

    table.style.display  = 'table';
    emptyPend.style.display = 'none';
    emptyAuth.style.display = 'none';
    tbody.innerHTML = '<tr><td colspan="3" style="text-align:center;padding:20px;color:#aaa;">Memuat data...</td></tr>';

    document.getElementById('tableHeader').innerHTML = `
        <th>Nama</th>
        <th>Email</th>
        <th>Lokasi</th>
        <th>Peran</th>`;

    try {
        const q    = query(collection(db, "pendaftaran"), where("status", "==", "authorized"));
        const snap = await getDocs(q);

        if (snap.empty) {
            table.style.display     = 'none';
            emptyAuth.style.display = 'block';
            return;
        }

        tbody.innerHTML = '';
        snap.forEach(docSnap => {
            const d  = docSnap.data();
            const tr = document.createElement('tr');
            const rolLabel = d.role === '1'
                ? '<span class="badge-role-petani">Petani Kopi</span>'
                : '<span class="badge-role-roaster">Roaster Kopi</span>';
            tr.innerHTML = `
                <td><b>${d.nama}</b></td>
                <td>${d.email}</td>
                <td>${d.lokasi}</td>
                <td>${rolLabel}</td>`;
            tbody.appendChild(tr);
        });
    } catch (err) {
        console.error(err);
        tbody.innerHTML = `<tr><td colspan="3" style="color:red;">Gagal memuat: ${err.message}</td></tr>`;
    }
}